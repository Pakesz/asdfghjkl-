
package com.demo.cardriverweb.Config;


public class Database {
    public static String PersistenceUnitName = "my_persistence_unit";
}
