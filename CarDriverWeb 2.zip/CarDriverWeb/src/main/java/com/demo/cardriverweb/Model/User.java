/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.cardriverweb.Model;

import com.demo.cardriverweb.Business.UserBusiness;
import com.demo.cardriverweb.Config.Database;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author asus
 */
@Entity
@Table(name = "User")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "User.findAll", query = "SELECT u FROM User u"),
    @NamedQuery(name = "User.findById", query = "SELECT u FROM User u WHERE u.id = :id"),
    @NamedQuery(name = "User.findByName", query = "SELECT u FROM User u WHERE u.name = :name"),
    @NamedQuery(name = "User.findByPhone", query = "SELECT u FROM User u WHERE u.phone = :phone"),
    @NamedQuery(name = "User.findByCarId", query = "SELECT u FROM User u WHERE u.carId = :carId")})
public class User implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "name")
    private String name;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "phone")
    private String phone;
    @Basic(optional = false)
    @NotNull
    @Column(name = "car_id")
    private int carId;

    public User() {
    }

    public User(Integer id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("my_persistence_unit");
        EntityManager em = emf.createEntityManager();
        
        User u = em.find(User.class,id);
        
        em.clear();
        em.close();
        emf.close();
        
        this.id = id;
        this.name = u.getName();
        this.carId = u.getCarId();
        this.phone = u.getPhone();
    }

    public User(Integer id, String name, String phone, int carId) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.carId = carId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof User)) {
            return false;
        }
        User other = (User) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.demo.cardriverweb.Model.User[ id=" + id + " ]";
    }
    
    // Tárolt eljárások meghívása
    
     public Boolean addUser(){
        try{
            EntityManagerFactory emf = Persistence.createEntityManagerFactory(Database.PersistenceUnitName);
            EntityManager em = emf.createEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addUser");

            spq.registerStoredProcedureParameter("nameIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("phoneIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("carIN", Integer.class, ParameterMode.IN);

            spq.setParameter("nameIN", this.name);
            spq.setParameter("phoneIN", this.phone);
            spq.setParameter("carIN", this.carId);

            spq.execute();
            //spq.getResultList(); 
            /*
             List<Object[]> result = spq.getResultList();
            List<Project> ten = new ArrayList();

            for(Object r: result){
                String szoveg = r.toString();
                Integer szam = Integer.parseInt(szoveg);
                UserXProjectXPositionXRole obj= new UserXProjectXPositionXRole(szam);
                Project p = new Project(obj.getProjectId());
                ten.add(p);
            }
            */

            em.clear();
            em.close();
            emf.close();
            return true;
        }
        catch(Exception ex){
            return false;
        }
    }
     
    public Boolean addCar(UserBusiness ub){
        try{
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("my_persistence_unit");
            EntityManager em = emf.createEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addCarToUser");
            
            spq.registerStoredProcedureParameter("carIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("userIN", Integer.class, ParameterMode.IN);
            
            spq.setParameter("carIN", ub.getCar().getId());
            spq.setParameter("userIN", ub.getId());
            
            spq.execute();
            return true;
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
            return false;
        }
    } 
    
    public Boolean addCar2(User u, Car c){
        try{
            EntityManagerFactory emf = Persistence.createEntityManagerFactory(Database.PersistenceUnitName);
            EntityManager em = emf.createEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addCarToUser");
            
            spq.registerStoredProcedureParameter("carIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("userIN", Integer.class, ParameterMode.IN);
            
            spq.setParameter("carIN", c.getId());
            spq.setParameter("userIN", u.getId());
            
            spq.execute();
            return true;
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
            return false;
        }
    }
}
