
package com.demo.cardriverweb.Service;

import com.demo.cardriverweb.Business.UserBusiness;
import com.demo.cardriverweb.Model.Car;
import com.demo.cardriverweb.Model.User;


public class UserService {
    public static UserBusiness business = new UserBusiness();
    
    public String addCarToUser(Integer uid, Integer cid){
        //validálás
        User user = new User(uid);
        Car car = new Car(cid);
        if(user.getName().length() == 0){
            return "Nincs ilyen user";
        }
        
        else if(car.getBrand().length() == 0){
            return "Nincs ilyen autó";
        }
        
        else if(business.addCarToUser(uid, cid)){
            return "Sikeres hozzáadás";
        }
        else{
            return "Sikertelen hozzáadás";
        }
    }
}
