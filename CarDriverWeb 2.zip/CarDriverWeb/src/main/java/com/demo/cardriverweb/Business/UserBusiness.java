
package com.demo.cardriverweb.Business;

import com.demo.cardriverweb.Config.Database;
import com.demo.cardriverweb.Model.Car;
import com.demo.cardriverweb.Model.User;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Persistence;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class UserBusiness {
//    
    
    
    private Integer id;
    private String name;
    private String phone;
    private Car car;
    public static User entity = new User();

    public UserBusiness(){
        
    }

    public UserBusiness(Integer id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(Database.PersistenceUnitName);
        EntityManager em = emf.createEntityManager();
        
        User u = em.find(User.class,id);
        
        em.clear();
        em.close();
        emf.close();
        
        Car car = new Car(u.getCarId());
        
        this.id = id;
        this.name = u.getName();
        this.phone = u.getPhone();
        this.car = car;
    }
    
    public UserBusiness(Integer id, Integer carId) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(Database.PersistenceUnitName);
        EntityManager em = emf.createEntityManager();
        
        User u = em.find(User.class,id);
        
        em.clear();
        em.close();
        emf.close();
        
        Car car = new Car(carId);
        
        this.id = id;
        this.name = u.getName();
        this.phone = u.getPhone();
        this.car = car;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
    
    
    public Boolean addCarToUser(Integer uid, Integer cid){
        UserBusiness obj = new UserBusiness(uid,cid);
        return entity.addCar(obj);
    }
    
}
