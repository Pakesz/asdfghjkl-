/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.cardriverweb.Business;

import com.demo.cardriverweb.Config.Database;
import com.demo.cardriverweb.Model.Car;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Persistence;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author asus
 */
public class CarBusiness {
    private static final long serialVersionUID = 1L;
   
    private Integer id;
    private String brand;
    private String type;
    private String color;

    public CarBusiness() {
    }

    public CarBusiness(Integer id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(Database.PersistenceUnitName);
        EntityManager em = emf.createEntityManager();
        Car car = em.find(Car.class, id);
        em.clear();
        em.close();
        emf.close();
        this.brand = car.getBrand();
        this.color = car.getColor();
        this.type = car.getType();
        this.id = id;
    }
    
    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
}
