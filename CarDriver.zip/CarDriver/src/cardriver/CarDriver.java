/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cardriver;

/**
 *
 * @author asus
 */
public class CarDriver {

    
    public static void main(String[] args) {
        User u = new User(2);
//        int auto = u.getCarId();
//        Car car = new Car(auto);
//        System.out.println(car.getBrand());

        UserBusiness ub = new UserBusiness(2);
        System.out.println(ub.getCar().getType());
        
        User u2 = new User("Lilla","1234",1);
        u2.addUser();
    }
    
}
