/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cardriver;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Persistence;


public class UserBusiness {
    
    private Integer id;
    private String name;
    private String phone;
    private Car car;

    public UserBusiness(Integer id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("CarDriverPU");
        EntityManager em = emf.createEntityManager();
        User user = em.find(User.class, id);
        this.id = id;
        this.name = user.getName();
        this.phone = user.getPhone();
        int carid = user.getCarId();
        this.car = em.find(Car.class, carid);
        // return this
        em.clear();
        em.close();
        emf.close();
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public Car getCar() {
        return car;
    }
    
    
}
